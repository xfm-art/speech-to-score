Pack downloaded from Freesound
----------------------------------------

"Voice Samples"

This Pack of sounds contains sounds by the following user:
 - honest_cactus ( https://freesound.org/people/honest_cactus/ )

You can find this pack online at: https://freesound.org/people/honest_cactus/packs/19518/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution 3.0: http://creativecommons.org/licenses/by/3.0/
Attribution NonCommercial 3.0: http://creativecommons.org/licenses/by-nc/3.0/
Attribution 4.0: https://creativecommons.org/licenses/by/4.0/


Sounds in this Pack
-------------------

  * 648469__honest_cactus__no-way.wav.wav
    * url: https://freesound.org/s/648469/
    * license: Attribution 4.0
  * 612310__honest_cactus__auto-phone-answer.wav.wav
    * url: https://freesound.org/s/612310/
    * license: Attribution 3.0
  * 376964__honest_cactus__bloopers.wav.wav
    * url: https://freesound.org/s/376964/
    * license: Creative Commons 0
  * 370034__honest_cactus__emotionless-monotone-request-by-lee.wav.wav
    * url: https://freesound.org/s/370034/
    * license: Creative Commons 0
  * 369929__honest_cactus__jd-trance-request.wav.wav
    * url: https://freesound.org/s/369929/
    * license: Creative Commons 0
  * 344250__honest_cactus__normal-voice-and-intro.wav.wav
    * url: https://freesound.org/s/344250/
    * license: Attribution NonCommercial 3.0


